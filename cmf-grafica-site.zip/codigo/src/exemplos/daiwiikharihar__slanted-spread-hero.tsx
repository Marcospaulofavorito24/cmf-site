"use client"

import SlantedSpreadHero from "@/components/ui/slanted-spread-hero"

export default function Page() {
  return (
    <main className="w-full min-h-screen bg-black text-white selection:bg-white selection:text-black">
       <SlantedSpreadHero/>
    </main>
  )
}