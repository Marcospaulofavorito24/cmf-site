import CTA from "@/components/ui/cta-01";

export default function CTADemo() {
  return <CTA />;
}
