import { useCallback, useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
  useTransform,
  type MotionValue,
} from "framer-motion";
import useEmblaCarousel from "embla-carousel-react";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  Building2,
  Camera,
  Check,
  FileCheck2,
  Menu,
  MessageCircle,
  Palette,
  RotateCw,
  ShoppingBag,
  X,
} from "lucide-react";
import Timeline from "@/components/ui/timeline-01-utils/timeline";
import Accordion from "@/components/ui/accordion";
import { cn } from "@/lib/utils";

/* ---------- marca ---------- */
const AZUL = "#1C3FA8";
const OURO = "#F2B705";
const TINTA = "#23272F";
const SUAVE = "#EEF0F4";
const CHAO = "#FAF7F1";
const BEGE = "#F3EBDD";
const CINZA = "#4A505C";

const WHATS =
  "https://wa.me/5511950502584?text=Ol%C3%A1%2C%20quero%20um%20or%C3%A7amento%20de%20cadernos%20personalizados.";
const SHOPEE = "https://shopee.com.br/graficascmf";
const INSTA = "https://instagram.com/graficacmf";

/* classe com regra própria no <style> abaixo (Tailwind v4 lê font-[...] como peso, não família) */
const serif = "cmf-serif";

if (typeof document !== "undefined") document.documentElement.classList.remove("dark");

const NAV = [
  { href: "#como", label: "Como pedir" },
  { href: "#pedidos", label: "Pedidos" },
  { href: "#empresas", label: "Empresas" },
  { href: "#faq", label: "Dúvidas" },
];

const FOTOS = [
  { src: "foto-1.jpg", legenda: "Capa de série, impressa em alta resolução." },
  { src: "foto-2.jpg", legenda: "Anime favorito, do jeito que o cliente mandou." },
  { src: "foto-3.jpg", legenda: "Escudo do time, em preto e branco." },
  { src: "foto-4.jpg", legenda: "Fundo marmorizado com escudo." },
  { src: "foto-5.jpg", legenda: "Camisa do time na capa." },
  { src: "foto-6.jpg", legenda: "Caderno com o logo da empresa, para a equipe." },
];

const PASSOS = [
  { date: "1", title: "Escolha o caderno", description: "Na nossa loja da Shopee, ou pelo WhatsApp para pedidos em quantidade.", image: "foto-6.jpg" },
  { date: "2", title: "Envie a capa", description: "Nome, frase, foto, arte ou logo. Em PNG, JPG ou PDF.", image: "foto-2.jpg" },
  { date: "3", title: "Aprove a prévia", description: "Mandamos uma prova digital com a capa montada. Só imprimimos depois do seu ok.", image: "foto-4.jpg" },
  { date: "4", title: "Receba em casa", description: "Produção em até 5 dias úteis para pedidos únicos, com envio rastreado.", image: "foto-5.jpg" },
];

const FAQ = [
  {
    title: "Posso mandar qualquer imagem para a capa?",
    description:
      "Sim: foto, ilustração, pôster ou logo. Quanto maior a resolução do arquivo, melhor a impressão. Se a imagem for pequena, avisamos na prévia.",
  },
  {
    title: "Vocês entregam para todo o Brasil?",
    description: "Sim. Pedidos pela Shopee saem com rastreio pelo próprio app. Pedidos corporativos combinamos o envio pelo WhatsApp.",
  },
  {
    title: "Qual é o pedido mínimo para empresas?",
    description: "10 unidades com o mesmo logo. Para quantidades maiores o valor unitário cai; peça o orçamento com a quantidade aproximada.",
  },
  {
    title: "Quanto tempo leva?",
    description:
      "Pedidos únicos: até 5 dias úteis de produção. Pedidos corporativos: 10 dias úteis depois de você aprovar a prova digital. Mais o prazo de envio.",
  },
];

type Estado = "normal" | "vazio" | "criando" | "erro";

function lerParams(): { estado: Estado; painel: boolean } {
  if (typeof window === "undefined") return { estado: "normal", painel: false };
  const p = new URLSearchParams(window.location.search);
  const e = p.get("estado");
  return {
    estado: e === "vazio" || e === "criando" || e === "erro" ? e : "normal",
    painel: p.get("painel") === "aberto",
  };
}

/* ---------- marca: traço azul + ponto dourado (viewBox com folga para o ponto nunca cortar) ---------- */

function Traco({ className, cor = AZUL }: { className?: string; cor?: string }) {
  return (
    <svg viewBox="0 0 440 164" aria-hidden className={className} overflow="visible">
      <path
        d="M10 120 C60 20 110 20 110 80 C110 150 40 150 60 100 C85 40 160 20 180 80 C200 150 125 150 145 100 C170 40 245 20 265 80 C285 150 210 150 230 100 C255 40 330 20 350 80 C365 125 330 150 402 112"
        fill="none"
        stroke={cor}
        strokeWidth="16"
        strokeLinecap="round"
      />
      <circle cx="414" cy="110" r="17" fill={OURO} />
    </svg>
  );
}

function Logo({ big = false, className }: { big?: boolean; className?: string }) {
  return (
    <span className={cn("inline-flex items-center", big ? "gap-4" : "gap-2.5", className)}>
      <Traco className={big ? "h-14 w-auto" : "h-8 w-auto"} />
      <span className={cn(serif, big ? "text-7xl" : "text-[32px]", "leading-none")} style={{ color: TINTA }}>
        CMF
      </span>
    </span>
  );
}

/* ---------- botões ---------- */

function BotaoAzul({
  href,
  children,
  className,
  size = "lg",
}: {
  href: string;
  children: ReactNode;
  className?: string;
  size?: "md" | "lg";
}) {
  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.97 }}
      className={cn(
        "group relative inline-flex items-center justify-center gap-2.5 overflow-hidden whitespace-nowrap rounded-full font-semibold text-white outline-none",
        "focus-visible:ring-4 focus-visible:ring-[#F2B705]/60",
        size === "lg" ? "h-14 px-7 text-[15px]" : "h-11 px-5 text-sm",
        className,
      )}
      style={{
        background: `linear-gradient(180deg, #2A50C2 0%, ${AZUL} 55%, #17368F 100%)`,
        boxShadow:
          "inset 0 1px 0 rgba(255,255,255,.35), inset 0 -2px 6px rgba(0,0,0,.18), 0 10px 30px -10px rgba(28,63,168,.65)",
      }}
    >
      <span
        aria-hidden
        className="pointer-events-none absolute inset-y-0 -left-1/2 w-1/3 -skew-x-12 bg-gradient-to-r from-transparent via-white/40 to-transparent opacity-0 transition-all duration-700 group-hover:left-[120%] group-hover:opacity-100"
      />
      <MessageCircle className={size === "lg" ? "size-5" : "size-4"} aria-hidden />
      <span className="relative">{children}</span>
    </motion.a>
  );
}

function BotaoVidro({
  href,
  children,
  icon,
  className,
}: {
  href: string;
  children: ReactNode;
  icon: ReactNode;
  className?: string;
}) {
  return (
    <motion.a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.97 }}
      className={cn(
        "inline-flex h-14 items-center justify-center gap-2.5 whitespace-nowrap rounded-full border border-white/80 bg-white/70 px-7 text-[15px] font-semibold backdrop-blur-xl outline-none",
        "shadow-[inset_0_1px_0_rgba(255,255,255,1),0_8px_24px_-12px_rgba(35,39,47,.35)] transition-colors hover:bg-white",
        "focus-visible:ring-4 focus-visible:ring-[#1C3FA8]/30",
        className,
      )}
      style={{ color: TINTA }}
    >
      {icon}
      {children}
    </motion.a>
  );
}

function BotaoTentar({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex h-11 items-center gap-2 rounded-full px-5 text-sm font-semibold text-white shadow-md transition hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#F2B705]/60"
      style={{ background: AZUL }}
    >
      <RotateCw className="size-4" aria-hidden />
      Tentar de novo
    </button>
  );
}

function Rotulo({ children, claro = false }: { children: ReactNode; claro?: boolean }) {
  return (
    <p className="flex items-center gap-2.5 text-sm font-semibold" style={{ color: claro ? "#fff" : AZUL }}>
      <span className="size-2 rounded-full" style={{ background: OURO }} aria-hidden />
      {children}
    </p>
  );
}

/* Foto com shimmer ao carregar e bloco calmo se falhar */
function Foto({
  src,
  alt,
  legenda,
  className,
  imgClassName,
  forcar,
  onFalha,
}: {
  src: string;
  alt: string;
  legenda?: string;
  className?: string;
  imgClassName?: string;
  forcar?: "criando" | "erro";
  onFalha?: () => void;
}) {
  const [st, setSt] = useState<"carregando" | "ok" | "erro">("carregando");
  const ref = useRef<HTMLImageElement>(null);
  useEffect(() => {
    if (ref.current?.complete && ref.current.naturalWidth > 0) setSt("ok");
  }, []);
  const estado = forcar === "criando" ? "carregando" : forcar === "erro" ? "erro" : st;
  return (
    <div className={cn("relative overflow-hidden", className)} style={{ background: SUAVE }}>
      {estado === "carregando" && <div className="cmf-shimmer absolute inset-0" aria-hidden />}
      {estado === "erro" ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
          <Traco className="h-8 w-auto opacity-70" />
          {legenda && (
            <p className="max-w-[26ch] text-sm font-semibold" style={{ color: TINTA }}>
              {legenda}
            </p>
          )}
        </div>
      ) : (
        !forcar && (
          <img
            ref={ref}
            src={src}
            alt={alt}
            draggable={false}
            onLoad={() => setSt("ok")}
            onError={() => {
              setSt("erro");
              onFalha?.();
            }}
            className={cn(
              "absolute inset-0 h-full w-full object-cover transition-opacity duration-700",
              st === "ok" ? "opacity-100" : "opacity-0",
              imgClassName,
            )}
          />
        )
      )}
    </div>
  );
}

/* ---------- hero: as sete capas num leque em arco (padrão da peça slanted-spread-hero) ---------- */

const ARCO = [
  { src: "foto-3.jpg", alt: "Caderno com o escudo do time em preto e branco", w: 10.5, r: -10, y: 74 },
  { src: "foto-6.jpg", alt: "Caderno com o logo de uma empresa na capa", w: 12.5, r: -6.5, y: 36 },
  { src: "foto-2.jpg", alt: "Caderno com capa de anime", w: 15, r: -3, y: 10 },
  { src: "foto-1.jpg", alt: "Caderno com capa de série", w: 18, r: 0, y: 0 },
  { src: "foto-5.jpg", alt: "Caderno com a camisa do time na capa", w: 15, r: 3, y: 10 },
  { src: "foto-7.jpg", alt: "Caderno marrom com o logo de uma doceria", w: 12.5, r: 6.5, y: 36 },
  { src: "foto-4.jpg", alt: "Caderno com fundo marmorizado e escudo", w: 10.5, r: 10, y: 74 },
];

function CartaArco({
  c,
  i,
  px,
  py,
  forcar,
}: {
  c: (typeof ARCO)[number];
  i: number;
  px: MotionValue<number>;
  py: MotionValue<number>;
  forcar?: "criando";
}) {
  const dist = Math.abs(i - 3);
  const depth = 1.4 - dist * 0.3;
  const x = useTransform(px, (p) => -p * 12 * depth);
  const y = useTransform(py, (p) => -p * 8 * depth);
  return (
    <motion.div
      className="relative shrink-0"
      style={{ width: `${c.w}%`, marginTop: c.y, zIndex: 10 - dist, x, y }}
      whileHover={{ scale: 1.08, zIndex: 40, transition: { type: "spring", stiffness: 260, damping: 22 } }}
    >
      <motion.div
        initial={{ opacity: 0, y: 70, rotate: 0, scale: 0.88 }}
        animate={{ opacity: 1, y: 0, rotate: c.r, scale: 1 }}
        transition={{ type: "spring", stiffness: 70, damping: 16, delay: 0.15 + dist * 0.09 }}
        className="relative"
      >
        <Foto
          src={c.src}
          alt={c.alt}
          forcar={forcar}
          className="aspect-square w-full rounded-[22px] ring-[5px] ring-white shadow-[0_40px_70px_-30px_rgba(35,39,47,.6),0_12px_24px_-14px_rgba(35,39,47,.35)]"
        />
        <div className="pointer-events-none absolute inset-0 rounded-[22px] bg-gradient-to-br from-white/20 via-transparent to-black/10" />
      </motion.div>
    </motion.div>
  );
}

function AvisoFotos({ estado, tentar }: { estado: "vazio" | "erro"; tentar: () => void }) {
  return (
    <div className="flex flex-col items-center gap-4 rounded-[28px] border border-white bg-white/70 px-8 py-10 text-center shadow-[0_30px_60px_-30px_rgba(28,63,168,.45)] backdrop-blur-xl">
      <Traco className="h-10 w-auto" />
      {estado === "vazio" ? (
        <>
          <p className={cn(serif, "text-[28px] leading-tight")} style={{ color: TINTA }}>
            As capas novas chegam aqui em breve.
          </p>
          <p className="max-w-[34ch] text-[15px]" style={{ color: CINZA }}>
            Enquanto isso, mande a sua ideia de capa pelo WhatsApp.
          </p>
        </>
      ) : (
        <>
          <p className={cn(serif, "text-[28px] leading-tight")} style={{ color: TINTA }}>
            As fotos dos cadernos não carregaram.
          </p>
          <BotaoTentar onClick={tentar} />
        </>
      )}
    </div>
  );
}

function StatusCarregando({ className }: { className?: string }) {
  return (
    <p
      role="status"
      className={cn(
        "flex items-center gap-2.5 whitespace-nowrap rounded-full border border-white bg-white/85 px-5 py-3 text-sm font-semibold shadow-lg backdrop-blur-xl",
        className,
      )}
      style={{ color: TINTA }}
    >
      <RotateCw className="size-4 animate-spin" style={{ color: AZUL }} aria-hidden />
      Carregando as fotos dos cadernos…
    </p>
  );
}

function HeroArco({ estado, tentar }: { estado: Estado; tentar: () => void }) {
  const reduce = useReducedMotion();
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const px = useSpring(rawX, { stiffness: 60, damping: 20, mass: 0.5 });
  const py = useSpring(rawY, { stiffness: 60, damping: 20, mass: 0.5 });

  useEffect(() => {
    if (reduce) return;
    const onMove = (e: PointerEvent) => {
      rawX.set((e.clientX / window.innerWidth - 0.5) * 2);
      rawY.set((e.clientY / window.innerHeight - 0.5) * 2);
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, [reduce, rawX, rawY]);

  const brilho = (
    <div
      aria-hidden
      className="pointer-events-none absolute left-1/2 top-1/2 h-[380px] w-[900px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-80 blur-[90px]"
      style={{
        background: `radial-gradient(circle at 35% 45%, ${AZUL}40, transparent 60%), radial-gradient(circle at 68% 60%, ${OURO}66, transparent 55%)`,
      }}
    />
  );

  if (estado === "vazio" || estado === "erro") {
    return (
      <div className="relative flex min-h-[300px] items-center justify-center">
        {brilho}
        <div className="relative w-[440px]">
          <AvisoFotos estado={estado} tentar={tentar} />
        </div>
      </div>
    );
  }

  return (
    <div className="relative mx-auto max-w-[1440px] px-6">
      {brilho}
      <div className="relative flex items-start justify-center gap-[1%] pb-4 pt-2">
        {ARCO.map((c, i) => (
          <CartaArco key={c.src} c={c} i={i} px={px} py={py} forcar={estado === "criando" ? "criando" : undefined} />
        ))}
      </div>
      {estado === "criando" && <StatusCarregando className="absolute bottom-0 left-1/2 z-[60] -translate-x-1/2" />}
    </div>
  );
}

function HeroFotosFone({ estado, tentar }: { estado: Estado; tentar: () => void }) {
  if (estado === "vazio" || estado === "erro") return <AvisoFotos estado={estado} tentar={tentar} />;
  const ordem = [ARCO[3], ARCO[2], ARCO[4], ARCO[1], ARCO[5], ARCO[0], ARCO[6]];
  return (
    <div className="relative -mx-5 sm:-mx-8">
      <div className="flex snap-x snap-mandatory scroll-px-5 gap-3.5 overflow-x-auto px-5 pb-5 pt-2 [mask-image:linear-gradient(to_right,black_86%,transparent)] [scrollbar-width:none] sm:scroll-px-8 sm:px-8 [&::-webkit-scrollbar]:hidden">
        {ordem.map((c) => (
          <Foto
            key={c.src}
            src={c.src}
            alt={c.alt}
            forcar={estado === "criando" ? "criando" : undefined}
            className="aspect-square w-[64%] shrink-0 snap-start rounded-[22px] ring-4 ring-white shadow-[0_24px_40px_-20px_rgba(35,39,47,.5)] sm:w-[40%]"
          />
        ))}
      </div>
      {estado === "criando" && (
        <div className="px-5 sm:px-8">
          <StatusCarregando className="w-fit" />
        </div>
      )}
    </div>
  );
}

/* ---------- galeria: faixa de cartões (padrão da peça carousel-08) ---------- */

function CartaoPedido({ foto, i, forcar }: { foto: (typeof FOTOS)[number]; i: number; forcar?: "criando" | "erro" }) {
  const rx = useMotionValue(0);
  const ry = useMotionValue(0);
  const srx = useSpring(rx, { stiffness: 180, damping: 18 });
  const sry = useSpring(ry, { stiffness: 180, damping: 18 });
  const [falhou, setFalhou] = useState(false);
  const semFoto = forcar === "erro" || falhou;

  return (
    <motion.figure
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.6, delay: (i % 3) * 0.08 }}
      style={{ rotateX: srx, rotateY: sry, transformPerspective: 900 }}
      onPointerMove={(e) => {
        if (e.pointerType !== "mouse") return;
        const r = e.currentTarget.getBoundingClientRect();
        ry.set(((e.clientX - r.left) / r.width - 0.5) * 10);
        rx.set(-((e.clientY - r.top) / r.height - 0.5) * 10);
      }}
      onPointerLeave={() => {
        rx.set(0);
        ry.set(0);
      }}
      className="group relative m-0 size-[300px] overflow-hidden rounded-[28px] shadow-[0_30px_60px_-30px_rgba(35,39,47,.55)] ring-1 ring-black/5 sm:size-[360px] lg:size-[400px]"
    >
      <Foto
        src={foto.src}
        alt={foto.legenda}
        legenda={foto.legenda}
        forcar={forcar}
        onFalha={() => setFalhou(true)}
        className="absolute inset-0"
        imgClassName="transition-transform duration-[900ms] ease-out group-hover:scale-110"
      />
      {!forcar && !semFoto && (
        <>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />
          <span className="absolute right-5 top-5 z-10 flex size-11 items-center justify-center rounded-full bg-white/90 shadow-md backdrop-blur">
            <ArrowUpRight className="size-5 transition-transform duration-300 group-hover:rotate-45" style={{ color: TINTA }} aria-hidden />
          </span>
          <figcaption
            className={cn(
              serif,
              "absolute inset-x-0 bottom-0 z-10 p-6 text-[22px] leading-[1.15] text-white transition-transform duration-500 group-hover:-translate-y-2 sm:p-7 sm:text-[26px]",
            )}
          >
            {foto.legenda}
          </figcaption>
        </>
      )}
    </motion.figure>
  );
}

function Galeria({ estado, tentar }: { estado: Estado; tentar: () => void }) {
  const [emblaRef, api] = useEmblaCarousel({ align: "start", dragFree: true, containScroll: "trimSnaps" });
  const [prev, setPrev] = useState(false);
  const [next, setNext] = useState(true);

  useEffect(() => {
    if (!api) return;
    const up = () => {
      setPrev(api.canScrollPrev());
      setNext(api.canScrollNext());
    };
    up();
    api.on("select", up);
    api.on("reInit", up);
    api.on("scroll", up);
    return () => {
      api.off("select", up);
      api.off("reInit", up);
      api.off("scroll", up);
    };
  }, [api]);

  useEffect(() => {
    api?.reInit();
  }, [estado, api]);

  const forcar = estado === "criando" ? "criando" : estado === "erro" ? "erro" : undefined;

  return (
    <section id="pedidos" className="py-20 lg:py-28">
      <div className="mx-auto flex max-w-[1250px] flex-col gap-6 px-5 sm:px-8 lg:flex-row lg:items-end lg:justify-between">
        <div className="space-y-4">
          <Rotulo>Pedidos entregues</Rotulo>
          <h2 className={cn(serif, "text-[40px] leading-[1.05] sm:text-6xl")} style={{ color: TINTA }}>
            Alguns que já saíram daqui.
          </h2>
        </div>
        {estado === "normal" && (
          <div className="hidden gap-3 lg:flex">
            {[
              { on: prev, fn: () => api?.scrollPrev(), Icon: ArrowLeft, l: "Anterior" },
              { on: next, fn: () => api?.scrollNext(), Icon: ArrowRight, l: "Próximo" },
            ].map(({ on, fn, Icon, l }) => (
              <button
                key={l}
                type="button"
                aria-label={l}
                onClick={fn}
                disabled={!on}
                className="flex size-12 items-center justify-center rounded-full border border-black/10 bg-white/80 shadow-sm backdrop-blur transition hover:-translate-y-0.5 hover:bg-white disabled:opacity-40 disabled:hover:translate-y-0 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#1C3FA8]/30"
                style={{ color: TINTA }}
              >
                <Icon className="size-5" />
              </button>
            ))}
          </div>
        )}
      </div>

      {estado === "vazio" ? (
        <div className="mx-auto mt-10 max-w-[1250px] px-5 sm:px-8">
          <div
            className="flex flex-col items-center gap-5 rounded-[32px] px-6 py-16 text-center"
            style={{ background: `linear-gradient(180deg, ${SUAVE}, ${BEGE})` }}
          >
            <Traco className="h-12 w-auto" />
            <p className={cn(serif, "text-3xl")} style={{ color: TINTA }}>
              Ainda não há fotos de pedidos por aqui.
            </p>
            <BotaoVidro href={INSTA} icon={<Camera className="size-5" style={{ color: AZUL }} />}>
              Instagram @graficacmf
            </BotaoVidro>
          </div>
        </div>
      ) : (
        <>
          {(estado === "criando" || estado === "erro") && (
            <div className="mx-auto mt-8 flex max-w-[1250px] flex-wrap items-center gap-4 px-5 sm:px-8" role="status" aria-live="polite">
              {estado === "criando" ? (
                <p className="flex items-center gap-3 text-[15px] font-medium" style={{ color: TINTA }}>
                  <RotateCw className="size-4 animate-spin" style={{ color: AZUL }} aria-hidden />
                  Carregando as fotos dos pedidos…
                </p>
              ) : (
                <>
                  <p className="text-[15px] font-medium" style={{ color: TINTA }}>
                    Não conseguimos carregar as fotos agora.
                  </p>
                  <BotaoTentar onClick={tentar} />
                </>
              )}
            </div>
          )}
          <div className="mt-8 overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_3%,black_94%,transparent)]" ref={emblaRef}>
            <div className="flex gap-5 px-5 py-6 sm:gap-6 sm:px-8 xl:px-[calc((100vw-1250px)/2+32px)]">
              {FOTOS.map((f, i) => (
                <div key={f.src} className="shrink-0">
                  <CartaoPedido foto={f} i={i} forcar={forcar} />
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </section>
  );
}

/* ---------- folha: menu + contato (superfície secundária) ---------- */

const linhaContato =
  "flex min-h-12 items-center gap-3 rounded-2xl px-4 text-[15px] font-medium transition hover:bg-white focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#1C3FA8]/30";

function Folha({ aberto, fechar }: { aberto: boolean; fechar: () => void }) {
  return (
    <AnimatePresence>
      {aberto && (
        <>
          <motion.div
            key="fundo"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={fechar}
            className="fixed inset-0 z-[65] hidden bg-[#23272F]/25 backdrop-blur-[2px] sm:block"
            aria-hidden
          />
          <motion.div
            key="folha"
            role="dialog"
            aria-label="Menu e contato"
            initial={{ x: "105%" }}
            animate={{ x: 0 }}
            exit={{ x: "105%" }}
            transition={{ type: "spring", stiffness: 280, damping: 32 }}
            className={cn(
              "fixed inset-0 z-[70] flex flex-col overflow-y-auto",
              "sm:inset-auto sm:bottom-4 sm:right-4 sm:top-4 sm:w-[420px] sm:rounded-[32px] sm:border sm:border-white",
              "sm:shadow-[0_40px_80px_-30px_rgba(28,63,168,.5),0_10px_30px_-15px_rgba(35,39,47,.35)]",
            )}
            style={{ background: `linear-gradient(180deg, ${CHAO}, ${BEGE})` }}
          >
            <div className="flex items-center justify-between px-5 pt-5 sm:px-6">
              <button
                type="button"
                onClick={fechar}
                aria-label="Voltar"
                className="flex size-11 items-center justify-center rounded-full bg-white shadow-sm ring-1 ring-black/5 transition hover:bg-[#EEF0F4] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#1C3FA8]/30 sm:hidden"
                style={{ color: TINTA }}
              >
                <ArrowLeft className="size-5" />
              </button>
              <Logo />
              <button
                type="button"
                onClick={fechar}
                aria-label="Fechar"
                className="hidden size-11 items-center justify-center rounded-full bg-white shadow-sm ring-1 ring-black/5 transition hover:bg-[#EEF0F4] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#1C3FA8]/30 sm:flex"
                style={{ color: TINTA }}
              >
                <X className="size-5" />
              </button>
              <span className="size-11 sm:hidden" aria-hidden />
            </div>

            <nav className="mt-6 flex flex-col px-5 sm:px-6" aria-label="Seções">
              {NAV.map((n, i) => (
                <motion.a
                  key={n.href}
                  href={n.href}
                  onClick={fechar}
                  initial={{ opacity: 0, x: 24 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 + i * 0.05 }}
                  className={cn(
                    serif,
                    "group flex min-h-16 items-center justify-between border-b border-[#23272F]/10 text-[32px] transition-colors hover:text-[#1C3FA8] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#1C3FA8]/30",
                  )}
                  style={{ color: TINTA }}
                >
                  {n.label}
                  <span className="flex size-10 items-center justify-center rounded-full bg-white shadow-sm transition-transform group-hover:translate-x-1">
                    <ArrowRight className="size-4" style={{ color: AZUL }} aria-hidden />
                  </span>
                </motion.a>
              ))}
            </nav>

            <div className="mx-5 mt-6 grid grid-cols-3 gap-2.5 sm:mx-6">
              {["foto-3.jpg", "foto-7.jpg", "foto-4.jpg"].map((s, i) => (
                <motion.div
                  key={s}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: i === 1 ? -6 : 0 }}
                  transition={{ delay: 0.25 + i * 0.06 }}
                >
                  <Foto src={s} alt="" className="aspect-[3/4] rounded-2xl ring-2 ring-white shadow-md" />
                </motion.div>
              ))}
            </div>

            <div className="mt-auto flex flex-col gap-2 px-5 pb-8 pt-6 sm:px-6 sm:pb-6">
              <BotaoAzul href={WHATS} className="mb-2 w-full">
                Pedir orçamento no WhatsApp
              </BotaoAzul>
              <a href={WHATS} target="_blank" rel="noopener noreferrer" className={linhaContato} style={{ color: TINTA }}>
                <MessageCircle className="size-5" style={{ color: AZUL }} aria-hidden />
                WhatsApp (11) 95050-2584
              </a>
              <a href={SHOPEE} target="_blank" rel="noopener noreferrer" className={linhaContato} style={{ color: TINTA }}>
                <ShoppingBag className="size-5" style={{ color: AZUL }} aria-hidden />
                Loja na Shopee
              </a>
              <a href={INSTA} target="_blank" rel="noopener noreferrer" className={linhaContato} style={{ color: TINTA }}>
                <Camera className="size-5" style={{ color: AZUL }} aria-hidden />
                Instagram @graficacmf
              </a>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/* ---------- tela ---------- */

export default function Tela() {
  const inicial = useRef(lerParams()).current;
  const [estado, setEstado] = useState<Estado>(inicial.estado);
  const [painel, setPainel] = useState(inicial.painel);
  const [rolou, setRolou] = useState(false);
  const [desceu, setDesceu] = useState(false);
  // UM botão de WhatsApp por vez (David, 08/10: "shows 3 times, it's too much"): enquanto o do herói aparece,
  // o do cabeçalho e o flutuante ficam escondidos; depois, no computador o do cabeçalho, no telefone o flutuante
  const acaoDoHeroi = useRef<HTMLDivElement>(null);
  const [heroiNaTela, setHeroiNaTela] = useState(true);
  useEffect(() => {
    const el = acaoDoHeroi.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => setHeroiNaTela(e.isIntersecting), { rootMargin: "-96px 0px 0px 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  const [largo, setLargo] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(min-width: 1024px)").matches,
  );

  useEffect(() => {
    document.documentElement.classList.remove("dark");
    document.documentElement.style.scrollBehavior = "smooth";
    document.body.style.background = CHAO;
    const on = () => {
      setRolou(window.scrollY > 24);
      setDesceu(window.scrollY > 560);
    };
    on();
    const mq = window.matchMedia("(min-width: 1024px)");
    const onMq = () => setLargo(mq.matches);
    mq.addEventListener("change", onMq);
    window.addEventListener("scroll", on, { passive: true });
    return () => {
      window.removeEventListener("scroll", on);
      mq.removeEventListener("change", onMq);
    };
  }, []);

  useEffect(() => {
    document.body.style.overflow = painel ? "hidden" : "";
  }, [painel]);

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.key === "Escape") setPainel(false);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);

  const fechar = useCallback(() => setPainel(false), []);
  const tentar = useCallback(() => {
    setEstado("criando");
    setTimeout(() => setEstado("normal"), 1400);
  }, []);

  const flutuante = !painel && !largo && !heroiNaTela;

  return (
    <div
      className="min-h-screen overflow-x-clip antialiased selection:bg-[#F2B705]/50"
      style={{ background: CHAO, color: TINTA, fontFamily: "Montserrat, system-ui, sans-serif" }}
    >
      <link
        rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Montserrat:wght@400;500;600;700&display=swap"
        precedence="default"
      />
      <style>{`
        .cmf-serif{font-family:"DM Serif Display",Georgia,serif;font-weight:400;letter-spacing:-0.005em}
        .cmf-shimmer{background:linear-gradient(100deg,${SUAVE} 20%,#ffffff 45%,${SUAVE} 70%);background-size:220% 100%;animation:cmf-sh 1.4s ease-in-out infinite}
        @keyframes cmf-sh{0%{background-position:120% 0}100%{background-position:-120% 0}}
        .cmf-timeline h3{font-family:"DM Serif Display",Georgia,serif;font-weight:400;letter-spacing:0}
        .cmf-timeline p.text-lg{font-family:"DM Serif Display",Georgia,serif;color:${AZUL};font-size:2.75rem;line-height:1}
        .cmf-timeline .bg-foreground{background:${AZUL}}
        .cmf-timeline .rounded-full.bg-foreground{background:${OURO};width:20px;height:20px}
        .cmf-timeline .overflow-hidden.rounded-2xl{border-radius:24px;box-shadow:0 30px 60px -30px rgba(35,39,47,.5);border:5px solid #fff}
        .cmf-timeline img{object-position:center;transition:transform .7s ease}
        .cmf-timeline .overflow-hidden.rounded-2xl:hover img{transform:scale(1.05)}
        @media (min-width:768px){.cmf-timeline .overflow-hidden.rounded-2xl{max-width:420px}}
        section[id]{scroll-margin-top:88px}
      `}</style>

      {/* faixa do topo, no azul da marca: traço inteiro, sem cortes */}
      <div className="relative z-50 text-white" style={{ background: AZUL }}>
        <p className="flex h-9 items-center justify-center gap-2.5 text-[13px] font-semibold tracking-wide">
          <Traco cor="#ffffff" className="h-3.5 w-auto" />
          Gráfica · São Paulo
        </p>
      </div>

      {/* cabeçalho de vidro */}
      <header
        className={cn(
          "sticky top-0 z-40 border-b transition-all duration-500",
          rolou
            ? "border-black/5 bg-[#FAF7F1]/75 shadow-[0_10px_40px_-20px_rgba(35,39,47,.35)] backdrop-blur-2xl"
            : "border-transparent bg-[#FAF7F1]/50 backdrop-blur-md",
        )}
      >
        <div className="mx-auto flex h-[72px] max-w-[1250px] items-center justify-between gap-4 px-5 sm:px-8">
          <a href="#" aria-label="CMF Gráfica" className="shrink-0 rounded-lg outline-none focus-visible:ring-4 focus-visible:ring-[#1C3FA8]/30">
            <Logo />
          </a>
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Principal">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="rounded-full px-4 py-2.5 text-[15px] font-medium transition-colors hover:bg-white/80 hover:text-[#1C3FA8] focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#1C3FA8]/25"
              >
                {n.label}
              </a>
            ))}
          </nav>
          <div className="flex shrink-0 items-center gap-2.5">
            <div
              className={cn("hidden transition-all duration-300 lg:block", heroiNaTela ? "pointer-events-none translate-y-1 opacity-0" : "opacity-100")}
              inert={heroiNaTela}
            >
              <BotaoAzul href={WHATS} size="md">
                Pedir orçamento no WhatsApp
              </BotaoAzul>
            </div>
            <button
              type="button"
              aria-label="Abrir menu e contato"
              aria-expanded={painel}
              onClick={() => setPainel(true)}
              className="flex size-11 items-center justify-center rounded-full border border-white bg-white/70 shadow-sm backdrop-blur transition hover:bg-white focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#1C3FA8]/30"
            >
              <Menu className="size-5" aria-hidden />
            </button>
          </div>
        </div>
      </header>

      <main>
        {/* HERO */}
        <section className="relative pb-14 lg:pb-16">
          <div
            aria-hidden
            className="pointer-events-none absolute inset-x-0 top-0 h-[760px]"
            style={{ background: `radial-gradient(60% 55% at 50% 70%, ${BEGE} 0%, transparent 70%)` }}
          />
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            className="relative mx-auto grid max-w-[1250px] gap-6 px-5 pt-8 sm:px-8 lg:grid-cols-[1.05fr_1fr] lg:items-end lg:gap-12 lg:pt-10"
          >
            <h1 className={cn(serif, "text-[46px] leading-[0.98] sm:text-7xl xl:text-[92px]")} style={{ color: TINTA }}>
              Seu nome em{" "}
              <em className="italic" style={{ color: AZUL }}>
                cada página.
              </em>
            </h1>
            <div className="flex flex-col gap-6 lg:pb-2">
              <p className="max-w-[520px] text-base leading-relaxed sm:text-lg" style={{ color: CINZA }}>
                Cadernos com a capa do seu jeito: o seu nome, a sua arte ou o logo da sua empresa. Feitos por dois irmãos e
                conferidos um a um antes de embalar.
              </p>
              <div ref={acaoDoHeroi} className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <BotaoAzul href={WHATS} className="w-full sm:w-auto">
                  Pedir orçamento no WhatsApp
                </BotaoAzul>
                <BotaoVidro href={SHOPEE} icon={<ShoppingBag className="size-5" style={{ color: AZUL }} />} className="w-full sm:w-auto">
                  Loja na Shopee
                </BotaoVidro>
              </div>
            </div>
          </motion.div>

          <div className="relative mx-auto mt-7 max-w-[1250px] px-5 sm:px-8 lg:hidden">
            <HeroFotosFone estado={estado} tentar={tentar} />
          </div>
          <div className="relative mt-10 hidden lg:block">
            <HeroArco estado={estado} tentar={tentar} />
          </div>

          <ul className="relative mx-auto mt-5 flex max-w-[1250px] flex-col items-start gap-2.5 px-5 sm:flex-row sm:flex-wrap sm:px-8 lg:mt-8 lg:justify-center">
            {[
              { t: "Capa personalizada", I: Palette },
              { t: "Empresas a partir de 10 un.", I: Building2 },
              { t: "Prova digital antes de imprimir", I: FileCheck2 },
            ].map(({ t, I }) => (
              <li
                key={t}
                className="flex items-center gap-2 whitespace-nowrap rounded-full border border-white bg-white/75 px-4 py-2.5 text-[13px] font-semibold shadow-[0_4px_14px_-8px_rgba(35,39,47,.3)] backdrop-blur"
              >
                <I className="size-4" style={{ color: AZUL }} aria-hidden />
                {t}
              </li>
            ))}
          </ul>
        </section>

        {/* COMO PEDIR — peça timeline */}
        <section
          id="como"
          className="py-16 lg:py-24"
          style={{ background: `linear-gradient(180deg, ${CHAO}, ${BEGE} 14%, ${BEGE} 86%, ${CHAO})` }}
        >
          <div className="mx-auto max-w-[1250px] px-5 sm:px-8">
            <div className="max-w-2xl space-y-4">
              <Rotulo>Como pedir</Rotulo>
              <h2 className={cn(serif, "text-[40px] leading-[1.05] sm:text-6xl")}>Quatro passos e o caderno é seu.</h2>
            </div>
            <div
              className="cmf-timeline mt-8 lg:mt-4"
              style={
                {
                  "--foreground": TINTA,
                  "--muted-foreground": CINZA,
                  "--border": "rgba(28,63,168,.18)",
                  "--background": "#ffffff",
                } as CSSProperties
              }
            >
              <Timeline items={PASSOS} />
            </div>
          </div>
        </section>

        {/* PEDIDOS */}
        <Galeria estado={estado} tentar={tentar} />

        {/* EMPRESAS — padrão da peça features-2 */}
        <section id="empresas" className="py-12 lg:py-32">
          <div className="mx-auto max-w-[1250px] px-4 sm:px-8">
            <div
              className="relative grid items-center gap-10 overflow-hidden rounded-[32px] px-6 py-12 text-white sm:px-12 lg:grid-cols-[1.1fr_1fr] lg:gap-16 lg:overflow-visible lg:px-16 lg:py-20"
              style={{
                background: `radial-gradient(70% 90% at 100% 0%, #3A63D8 0%, transparent 60%), radial-gradient(50% 60% at 0% 100%, ${OURO}33 0%, transparent 60%), ${AZUL}`,
                boxShadow: "inset 0 1px 0 rgba(255,255,255,.25), 0 50px 100px -50px rgba(28,63,168,.7)",
              }}
            >
              <motion.div
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.7 }}
                className="relative flex flex-col gap-6"
              >
                <Rotulo claro>Empresas</Rotulo>
                <h2 className={cn(serif, "text-[38px] leading-[1.05] sm:text-[52px]")}>
                  O logo da sua empresa, em cima da mesa o ano inteiro.
                </h2>
                <p className="max-w-[520px] text-base leading-relaxed text-white/90 sm:text-[17px]">
                  Brindes de fim de ano, kits de boas-vindas e eventos. Caneca acumula e chaveiro some; o caderno fica aberto na
                  mesa, com a sua marca na capa.
                </p>
                <ul className="flex flex-col gap-3.5">
                  {[
                    "A partir de 10 unidades",
                    "Prova digital antes de produzir",
                    "Pronto em 10 dias úteis depois da aprovação",
                    "Brindes de fim de ano: pedidos até 30/11",
                  ].map((b) => (
                    <li key={b} className="flex items-center gap-3 text-[15px] font-medium">
                      <span className="flex size-6 shrink-0 items-center justify-center rounded-md shadow-sm" style={{ background: OURO }}>
                        <Check className="size-3.5" strokeWidth={3} style={{ color: TINTA }} aria-hidden />
                      </span>
                      {b}
                    </li>
                  ))}
                </ul>
                <div className="pt-2">
                  <motion.a
                    href={WHATS}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ y: -2 }}
                    whileTap={{ scale: 0.97 }}
                    className="group inline-flex h-14 w-full items-center justify-center gap-2.5 rounded-full px-7 text-[15px] font-bold shadow-[inset_0_1px_0_rgba(255,255,255,.6),0_14px_30px_-12px_rgba(0,0,0,.4)] outline-none focus-visible:ring-4 focus-visible:ring-white/60 sm:w-auto"
                    style={{ background: OURO, color: TINTA }}
                  >
                    Pedir orçamento
                    <ArrowRight className="size-5 transition-transform group-hover:translate-x-1" aria-hidden />
                  </motion.a>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 40, rotate: 0 }}
                whileInView={{ opacity: 1, y: 0, rotate: 3 }}
                viewport={{ once: true, margin: "-80px" }}
                transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ rotate: 0, scale: 1.02 }}
                className="relative lg:-my-36"
              >
                <Foto
                  src="foto-7.jpg"
                  alt="Caderno marrom com o logo de uma doceria na capa"
                  className="aspect-square w-full rounded-[28px] shadow-[0_60px_100px_-30px_rgba(10,20,60,.7)] ring-[6px] ring-white"
                />
              </motion.div>
            </div>
          </div>
        </section>

        {/* FAQ — peça accordion */}
        <section id="faq" className="py-16 lg:py-24">
          <div className="mx-auto grid max-w-[1250px] gap-10 px-5 sm:px-8 lg:grid-cols-[1fr_1.15fr] lg:gap-20">
            <div className="lg:pt-6">
              <div className="space-y-4 lg:sticky lg:top-32">
                <Rotulo>Dúvidas</Rotulo>
                <h2 className={cn(serif, "text-[40px] leading-[1.05] sm:text-6xl")}>Perguntas que sempre chegam.</h2>
              </div>
            </div>
            <div className="relative">
              <div
                aria-hidden
                className="pointer-events-none absolute -inset-10 rounded-full opacity-60 blur-3xl"
                style={{
                  background: `radial-gradient(50% 50% at 30% 30%, ${AZUL}26, transparent 70%), radial-gradient(40% 40% at 80% 80%, ${OURO}40, transparent 70%)`,
                }}
              />
              <Accordion
                items={FAQ}
                className={cn(
                  "relative",
                  "[&>div]:max-w-none [&>div]:rounded-[28px] [&>div]:from-white/70 [&>div]:to-[#EEF0F4]/80 [&>div]:p-2 [&>div]:shadow-[0_30px_60px_-35px_rgba(28,63,168,.45)] [&>div]:ring-1 [&>div]:ring-white [&>div]:backdrop-blur-xl",
                  "[&_.rounded-xl]:rounded-[20px] [&_.rounded-xl]:border-black/5",
                  "[&_button]:min-h-16 [&_button]:gap-4 [&_button]:px-6 [&_button]:text-[17px] [&_button]:font-semibold [&_button]:!text-[#23272F]",
                  "[&_button:hover]:!text-[#1C3FA8] [&_button:focus-visible]:outline-none [&_button:focus-visible]:ring-4 [&_button:focus-visible]:ring-inset [&_button:focus-visible]:ring-[#1C3FA8]/30",
                  "[&_button_.text-lg]:text-2xl [&_button_.text-lg]:!text-[#1C3FA8]",
                  "[&_.text-gray-500]:px-6 [&_.text-gray-500]:pb-6 [&_.text-gray-500]:text-[15px] [&_.text-gray-500]:!text-[#4A505C]",
                )}
              />
            </div>
          </div>
        </section>
      </main>

      {/* RODAPÉ — padrão da peça cta-01 */}
      <footer style={{ background: SUAVE }}>
        <div className="mx-auto max-w-[1250px] px-4 pb-28 pt-12 sm:px-8 sm:py-20">
          <div className="relative isolate flex min-h-96 items-center justify-center overflow-hidden rounded-[32px] border border-white bg-white/60 px-6 py-14 shadow-[0_40px_80px_-50px_rgba(28,63,168,.5)]">
            <div
              aria-hidden
              className="absolute left-0 top-24 -z-10 h-4/5 w-full rounded-full blur-3xl"
              style={{ background: `linear-gradient(90deg, ${AZUL}33 15%, #ffffff 55%, ${OURO}55 90%)` }}
            />
            <motion.div
              initial={{ y: "5%", opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1, delay: 0.2 }}
              className="flex flex-col items-center gap-8 text-center"
            >
              <Logo big />
              <a
                href={WHATS}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative inline-flex h-14 items-center overflow-hidden rounded-full pe-16 ps-7 text-[15px] font-semibold text-white transition-all duration-500 hover:pe-7 hover:ps-16 focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#F2B705]/60"
                style={{ background: AZUL, boxShadow: "inset 0 1px 0 rgba(255,255,255,.3), 0 14px 30px -12px rgba(28,63,168,.7)" }}
              >
                <span className="relative z-10">WhatsApp (11) 95050-2584</span>
                <span
                  className="absolute right-1.5 flex size-11 items-center justify-center rounded-full bg-white transition-all duration-500 group-hover:right-[calc(100%-50px)] group-hover:rotate-45"
                  style={{ color: AZUL }}
                >
                  <ArrowUpRight className="size-5" />
                </span>
              </a>
              <div className="flex flex-wrap justify-center gap-3">
                <BotaoVidro href={SHOPEE} icon={<ShoppingBag className="size-5" style={{ color: AZUL }} />} className="h-12 px-6">
                  Shopee
                </BotaoVidro>
                <BotaoVidro href={INSTA} icon={<Camera className="size-5" style={{ color: AZUL }} />} className="h-12 px-6">
                  Instagram @graficacmf
                </BotaoVidro>
              </div>
            </motion.div>
          </div>
          <p className="mt-8 text-center text-sm font-medium" style={{ color: CINZA }}>
            CMF Gráfica · São Paulo, SP
          </p>
        </div>
      </footer>

      {/* botão flutuante do WhatsApp: só no telefone, depois que o botão do herói sai da tela */}
      <motion.a
        href={WHATS}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Pedir orçamento no WhatsApp"
        aria-hidden={!flutuante}
        tabIndex={flutuante ? 0 : -1}
        initial={{ opacity: 0, y: 24, scale: 0.9 }}
        animate={{ opacity: flutuante ? 1 : 0, y: flutuante ? 0 : 24, scale: flutuante ? 1 : 0.9 }}
        transition={{ type: "spring", stiffness: 260, damping: 24 }}
        whileHover={{ y: -3 }}
        whileTap={{ scale: 0.95 }}
        className={cn(
          "group fixed bottom-5 right-5 z-[60] flex size-16 items-center justify-center gap-2.5 rounded-full text-white focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-[#F2B705]/60",
          "sm:bottom-6 sm:right-6 sm:w-auto sm:pl-2.5 sm:pr-7",
          !flutuante && "pointer-events-none",
        )}
        style={{
          background: `linear-gradient(180deg, #2A50C2, ${AZUL} 60%, #17368F)`,
          boxShadow: "inset 0 1px 0 rgba(255,255,255,.35), 0 0 0 6px rgba(255,255,255,.6), 0 22px 44px -14px rgba(28,63,168,.8)",
        }}
      >
        <span className="relative flex size-11 items-center justify-center rounded-full bg-white/15">
          <MessageCircle className="size-6" aria-hidden />
          <span className="absolute -right-0.5 -top-0.5 size-3.5 rounded-full ring-2 ring-[#1C3FA8]" style={{ background: OURO }} aria-hidden>
            <span className="absolute inset-0 animate-ping rounded-full opacity-60" style={{ background: OURO }} />
          </span>
        </span>
        <span className="hidden text-[15px] font-semibold sm:inline">Pedir orçamento no WhatsApp</span>
      </motion.a>

      <Folha aberto={painel} fechar={fechar} />
    </div>
  );
}
