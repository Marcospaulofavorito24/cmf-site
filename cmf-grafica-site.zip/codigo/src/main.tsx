import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import Tela from "./Tela";
createRoot(document.getElementById("root")!).render(<StrictMode><Tela /></StrictMode>);
